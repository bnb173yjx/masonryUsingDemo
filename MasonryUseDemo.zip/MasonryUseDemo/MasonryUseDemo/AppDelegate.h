//
//  AppDelegate.h
//  MasonryUseDemo
//
//  Created by 叶杨 on 16/8/10.
//  Copyright © 2016年 Xansurs Ye. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

