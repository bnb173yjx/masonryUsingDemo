//
//  ViewController.m
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import <UIKit/UIKit.h>

/*
 *此类不作使用
 *可以将此类的名称噶成你工程名里头的基类
 *基类一般的工作就是处理键盘回弹,和处理警告框和提示框等
 */


@interface BaseViewController : UIViewController


@end
