//
//  ViewController.m
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//


#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

//- (instancetype)initWithLastBarHidden:(BOOL)lastHidden {
//    self = [super init];
//    if (self) {
//        self.lastBarHidden = YES;
//    }
//    return self;
//}

- (void)viewDidLoad {
    [super viewDidLoad];
    

    //解决进入到新的视图时有残影问题
    self.view.backgroundColor = [UIColor whiteColor];
    if ([self respondsToSelector:@selector(setEdgesForExtendedLayout:)]) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
    }
    
}

- (void)dealloc {
    NSLog(@" %@ will dealloc ! ", NSStringFromClass([self class]));
}

@end
