//
//  CustomDefine.h
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//


#ifndef CustomDefine_h
#define CustomDefine_h
//屏幕
//屏幕大小
#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)



//线的宽度
#define ONELINE_WIDTH 0.5f
//view
//这个是点击视图的时候，视图变灰色会产生的block，在block里头要用weakSelf,主要是YMBaseInfoView机器基类使用
typedef void(^ActionBlock)(void);
//Masonry
#define mas_equalTo(...)                 equalTo(MASBoxValue((__VA_ARGS__)))
#define mas_greaterThanOrEqualTo(...)    greaterThanOrEqualTo(MASBoxValue((__VA_ARGS__)))
#define mas_lessThanOrEqualTo(...)       lessThanOrEqualTo(MASBoxValue((__VA_ARGS__)))
#define mas_offset(...)                  valueOffset(MASBoxValue((__VA_ARGS__)))

//弱引用
#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;

//url,图片
#define YmURL(urlString)    [NSURL URLWithString:urlString]
#define YmImage(imageName)   [UIImage imageNamed:imageName]
/*
 字体
 */
#define CreateFont(font) [UIFont systemFontOfSize:font]
#define NormalFont CreateFont(13)
#define StrongFont(font)      [UIFont fontWithName:@"Helvetica-Bold" size:font]

//线宽度
#define ONELINE_WIDTH 0.5f

//颜色
#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]
#define RGBCOLOR(r,g,b) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1]
#define HEXRGB(rgbValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0xFF00) >> 8))/255.0 blue:((float)(rgbValue & 0xFF))/255.0 alpha:1.0]

//原点颜色
#define OriginColor         HEXRGB(0xfb413b)

#define LineColor           HEXRGB(0xdbdbdb)
#define NormalBgColor       HEXRGB(0xededed)



#endif /* CustomDefine_h */
