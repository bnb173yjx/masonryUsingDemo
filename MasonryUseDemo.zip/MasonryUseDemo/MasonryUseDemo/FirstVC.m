//
//  FirstVC.m
//  MasonryUseDemo
//
//  Created by 叶杨 on 16/8/10.
//  Copyright © 2016年 Xansurs Ye. All rights reserved.
//

#import "FirstVC.h"
#import "YMBaseInfoView.h"
#import "ImageArrowView.h"
#import "MappingView.h"
#import "ArrowView.h"
#import "OneArrowView.h"
#import "ImageArrowView.h"
#import "MappArrowView.h"
#import "TipBlockView.h"
#import "TipImageView.h"
#import "TitleView.h"


@interface FirstVC ()

@property(nonatomic,strong)YMBaseInfoView *baseInfoView;
@property (nonatomic, strong)ImageArrowView *imageArrowView;
@property (nonatomic, strong)MappArrowView *mapArrowView;
@property (nonatomic, strong)OneArrowView *oneArrowView;
@property (nonatomic, strong)MappingView *mappingView;
@property (nonatomic, strong)TipBlockView *tipBlockView;
@property (nonatomic, strong)TitleView *titleView;
@property (nonatomic, strong)TipImageView *tipImageView;

@end


@implementation FirstVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"masonry使用";
    [self setupView];
    
    
}


- (void)setupView {
    [super setupView];
    
    self.baseInfoView = [[YMBaseInfoView alloc]init];
    self.imageArrowView = [[ImageArrowView alloc]init];
    self.imageArrowView.leftIV.backgroundColor = [UIColor blackColor];
    
    
    self.mapArrowView = [[MappArrowView alloc]init];
    self.mapArrowView.tipLab.text = @"tip";
    [self.mapArrowView setInfoLabText:@"info"];
    
    
    self.oneArrowView = [[OneArrowView alloc]init];
    
    
    self.mappingView = [[MappingView alloc]init];
    [self.mappingView setTipLabText:@"tip"];
    [self.mappingView setInfoLabText:@"info"];
    
    
    self.tipBlockView = [[TipBlockView alloc]init];
    [self.tipBlockView setTipLabText:@"tip"];
    
    self.titleView = [[TitleView alloc]init];
    [self.titleView setPlaceholderStr:@"这是一个titleview"];
    
    self.tipImageView = [[TipImageView alloc]init];
    [self.tipImageView setTipLabText:@"tip"];
    
    
    NSArray *viewArr = @[
                         self.baseInfoView,
                         self.imageArrowView,
                         self.mapArrowView,
                         self.oneArrowView,
                         self.mappingView,
                         self.tipBlockView,
                         self.titleView
                         ];
    [self setFullLine:viewArr];
    [self addSubviewWith:viewArr];
    [self.container addSubview:self.tipImageView];
    
    [self addMasonryViewForArray:viewArr andHeight:42 andtopView:nil andSpan:12];
    [self addMasonryView:self.tipImageView topView:self.titleView span:12 height:100];
    WS(weakSelf)
    [self.container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(weakSelf.tipImageView.mas_bottom).with.offset(0);
    }];

}

- (void)setFullLine: (NSArray *)baseInfoArr {
    for (YMBaseInfoView *baseInfoView in baseInfoArr) {
        baseInfoView.bottomLineStyle = YmViewLineStyleFill;
        baseInfoView.topLineStyle = YmViewLineStyleFill;
    }
  
}


@end
