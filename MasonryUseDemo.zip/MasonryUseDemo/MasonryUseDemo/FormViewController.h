//
//  ViewController.m
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//


#import "BaseViewController.h"

@interface FormViewController : BaseViewController
@property (strong, nonatomic) UIScrollView* scrollView;
@property (strong, nonatomic) UIView* container;

- (void)setupView;

- (void)addMasonryViewForArray:(NSArray *)arr andHeight:(CGFloat)height andtopView:(UIView *)firstTopView andSpan: (CGFloat) span;
- (void)addMasonryView:(UIView*)view topView:(UIView*)top span:(CGFloat)span height:(CGFloat)height;

- (void)addMasonryView:(UIView*)view topView:(UIView*)top topSpan:(CGFloat)span leftSpan:(CGFloat)leftSpan rightSpan:(CGFloat)rightSpan height:(CGFloat)height;

- (void)addSubviewWith:(NSArray *)array;

@end
