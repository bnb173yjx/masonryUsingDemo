//
//  ViewController.m
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//


#import "FormViewController.h"

@interface FormViewController ()

@end

@implementation FormViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)setupView {
    WS(weakSelf)
    UIScrollView *scrollView = [UIScrollView new];
    scrollView.backgroundColor = HEXRGB(0xf8f8f8);
    scrollView.alwaysBounceVertical = YES;
    scrollView.delaysContentTouches = NO;
    [self.view addSubview:scrollView];
    [scrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(weakSelf.view);
    }];
    self.scrollView = scrollView;
    
    UIView *container = [UIView new];
    container.backgroundColor = HEXRGB(0xf8f8f8);
    [scrollView addSubview:container];
    [container mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(scrollView);
        make.width.equalTo(scrollView);
    }];
    self.container = container;

}

- (void)addMasonryViewForArray:(NSArray *)arr andHeight:(CGFloat)height andtopView:(UIView *)firstTopView andSpan: (CGFloat) span {
    for (NSInteger i =0 ; i < arr.count; i++) {
        //        UIView *lastView = arr[i ]
        UIView *nowView = arr[i];
        [self addMasonryView:nowView topView: (i == 0 ?  firstTopView : (UIView *)arr[i - 1]) span:span height:height];
    }
}

- (void)addMasonryView:(UIView*)view topView:(UIView*)top span:(CGFloat)span height:(CGFloat)height {
    WS(weakSelf)
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(top?top.mas_bottom:weakSelf.container.mas_top).with.offset(span);
        make.left.and.right.equalTo(weakSelf.container);
        make.height.mas_equalTo(@(height));
    }];
}

- (void)addMasonryView:(UIView *)view topView:(UIView *)top topSpan:(CGFloat)span leftSpan:(CGFloat)leftSpan rightSpan:(CGFloat)rightSpan height:(CGFloat)height
{
    WS(weakSelf)
    [view mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(top?top.mas_bottom:weakSelf.container.mas_top).with.offset(span);
        make.left.equalTo(weakSelf.container.mas_left).with.offset(leftSpan);
        make.right.equalTo(weakSelf.container.mas_right).with.offset(-rightSpan);
        make.height.mas_equalTo(@(height));
    }];
}


- (void)addSubviewWith:(NSArray *)array {
    for (UIView *view in array) {
        [self.container addSubview:view];
    }
}



- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
//    WS(weakSelf)
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
