//
//  YMBaseInfoView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YMBaseInfoView.h"

//一个lab + 一个箭头
@interface ArrowView : YMBaseInfoView
@property (nonatomic, strong) UILabel* tipLab;
@property (nonatomic, strong) UIImageView* arrowImageView;
- (void)setTip:(NSString*)tip;
- (void)setArrowHide:(BOOL)hide;

//- (void)setupView ;
//- (void)addArrowViewMasonry ;
@end
