//
//  YMBaseInfoView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//


#import "ArrowView.h"

@implementation ArrowView


- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self setupView];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupView];
    }
    return self;
}

- (void)setupView {
    self.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.tipLab];
    [self addSubview:self.arrowImageView];
    [self addArrowViewMasonry];
}

- (void)addArrowViewMasonry {
    WS(weakSelf)
    [self.tipLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.mas_left).with.offset(16);
        make.centerY.mas_equalTo(weakSelf.mas_centerY);
    }];
    
    [self.arrowImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(weakSelf.mas_right).with.offset(-16);
        make.centerY.mas_equalTo(weakSelf.mas_centerY);
    }];
}

- (void)setTip:(NSString*)tip {
    self.tipLab.text = tip;
}

- (void)setArrowHide:(BOOL)hide {
    self.arrowImageView.hidden = hide;
}

- (UILabel *)tipLab {
    if (_tipLab == nil) {
        _tipLab = [[UILabel alloc] init];
        [_tipLab setFont:CreateFont(17)];
        _tipLab.text = @"发送对象";
    }
    return _tipLab;
}

- (UIImageView*)arrowImageView {
    if (_arrowImageView == nil) {
        _arrowImageView = [[UIImageView alloc] init];
        _arrowImageView.image = [UIImage imageNamed:@"arrow_right"];
    }
    return _arrowImageView;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    if (![self.superview.superview isKindOfClass:[UITableViewCell class]]) {
        [self setBackgroundColor:NormalBgColor];
    }
    
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesEnded:touches withEvent:event];
    if (![self.superview.superview isKindOfClass:[UITableViewCell class]]) {
        [self setBackgroundColor:[UIColor whiteColor]];
    }
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesCancelled:touches withEvent:event];
    if (![self.superview.superview isKindOfClass:[UITableViewCell class]]) {
        [self setBackgroundColor:[UIColor whiteColor]];
    }
}


@end
