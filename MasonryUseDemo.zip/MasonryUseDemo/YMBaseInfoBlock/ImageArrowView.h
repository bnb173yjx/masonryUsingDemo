//
//  ImageArrowView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/5/15.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "ArrowView.h"

@interface ImageArrowView : ArrowView


@property (nonatomic, strong)UIImageView *leftIV;

- (void)setLeftImage:(UIImage *)image;


@end
