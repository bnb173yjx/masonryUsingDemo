//
//  ImageArrowView.m
//  YanmianTest
//
//  Created by 叶杨 on 16/5/15.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "ImageArrowView.h"

@implementation ImageArrowView

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self setupSelfView];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupSelfView];
    }
    return self;
}
- (void)setupSelfView
{
//    [super setupView];
    [self addSubview:self.leftIV];
    [self addLeftIVMasonry];
}

- (void)addLeftIVMasonry
{
    WS(weakSelf);
    
    [self.leftIV mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(weakSelf.mas_left).with.offset(30);
        make.centerY.mas_equalTo(weakSelf.mas_centerY);
//        make.top.equalTo(weakSelf.mas_top).with.offset(4);
        make.size.width.and.height.mas_equalTo(30);//equalTo(weakSelf.mas_height).with.offset(-5);
 
    }];

    [self.tipLab mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.leftIV.mas_right).with.offset(10);
        make.centerY.mas_equalTo(weakSelf.mas_centerY);
    }];
}

- (UIImageView *)leftIV
{
    if (_leftIV == nil) {
        _leftIV = [[UIImageView alloc]init];
//        _leftIV.image = [UIImage imageNamed:@"ic_next"];;
    }
    return _leftIV;
}

- (void)setLeftImage:(UIImage *)image
{
    self.leftIV.image = image;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
