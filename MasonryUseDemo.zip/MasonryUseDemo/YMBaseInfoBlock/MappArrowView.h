//
//  MappArrowView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/6/2.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "MappingView.h"

@interface MappArrowView : MappingView

- (void)setArrowHidden:(BOOL)isHidden;



@end
