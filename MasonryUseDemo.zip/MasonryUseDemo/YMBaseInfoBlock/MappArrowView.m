//
//  MappArrowView.m
//  YanmianTest
//
//  Created by 叶杨 on 16/6/2.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "MappArrowView.h"

@interface MappArrowView ()

@property (nonatomic, strong)UIImageView *arrowImageView;

@end

@implementation MappArrowView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupMappArrowView];
    }
    return self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    self = [super initWithCoder:aDecoder];
    if (self) {
        [self setupMappArrowView];
    }
    return self;
}

- (void)setupMappArrowView {
    [self addSubview:self.arrowImageView];
    [self bringSubviewToFront:self.arrowImageView];
    [self addMasonryToMappArrowView];
}

- (void)addMasonryToMappArrowView {
    WS(weakSelf);
    [self.arrowImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(weakSelf.mas_right).with.offset(-8);
        make.centerY.mas_equalTo(weakSelf.mas_centerY);
    }];
    [self.infoLab mas_remakeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(weakSelf.mas_right).with.offset(-25);
        make.centerY.equalTo(weakSelf.mas_centerY);
        make.width.mas_equalTo(180);
    }];
}

- (UIImageView*)arrowImageView {
    if (_arrowImageView == nil) {
        _arrowImageView = [[UIImageView alloc] init];
        _arrowImageView.image = [UIImage imageNamed:@"arrow_right"];
    }
    return _arrowImageView;
}

- (void)setArrowHidden:(BOOL)isHidden {
    self.arrowImageView.hidden = isHidden;
    WS(weakSelf)
    if (isHidden) {
        [self.infoLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(weakSelf.mas_right).with.offset(-10);
            make.centerY.equalTo(weakSelf.mas_centerY);
            make.width.mas_equalTo(180);
        }];
    }else{
        [self.infoLab mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(weakSelf.mas_right).with.offset(-25);
            make.centerY.equalTo(weakSelf.mas_centerY);
            make.width.mas_equalTo(180);
        }];
    }
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    if (![self.superview.superview isKindOfClass:[UITableViewCell class]]) {
        [self setBackgroundColor:NormalBgColor];
    }
    
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesEnded:touches withEvent:event];
    if (![self.superview.superview isKindOfClass:[UITableViewCell class]]) {
        [self setBackgroundColor:[UIColor whiteColor]];
    }
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesCancelled:touches withEvent:event];
    if (![self.superview.superview isKindOfClass:[UITableViewCell class]]) {
        [self setBackgroundColor:[UIColor whiteColor]];
    }
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
