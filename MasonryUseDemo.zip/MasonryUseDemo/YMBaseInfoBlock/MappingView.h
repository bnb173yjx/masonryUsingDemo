//
//  YMBaseInfoView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "TipBlockView.h"

//key - value
@interface MappingView : TipBlockView
@property (nonatomic, strong) UILabel* infoLab;
- (void)setInfoLabText:(NSString*)text;
- (NSString *)infoLabText;
@end
