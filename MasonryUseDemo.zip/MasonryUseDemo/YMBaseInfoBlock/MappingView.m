//
//  YMBaseInfoView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "MappingView.h"

@interface MappingView ()

@end

@implementation MappingView

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self setupMappingView];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupMappingView];
    }
    return self;
}

- (void)setupMappingView {
    [self addSubview:self.infoLab];
    [self addMappingViewMasonry];
}

- (void)addMappingViewMasonry {
    WS(weakSelf)
    
    [self.infoLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(weakSelf.mas_right).with.offset(-16);
        make.centerY.mas_equalTo(weakSelf.mas_centerY);
    }];
}

- (UILabel *)infoLab {
    if (_infoLab == nil) {
        _infoLab = [[UILabel alloc] init];
        [_infoLab setFont:CreateFont(13)];
        _infoLab.textAlignment = NSTextAlignmentRight;
//        _infoLab.textColor = HEXRGB(0x999999);
    }
    return _infoLab;
}

- (void)setInfoLabText:(NSString*)text {
    self.infoLab.text = text;
}

- (NSString *)infoLabText {
    return self.infoLab.text;
}

@end
