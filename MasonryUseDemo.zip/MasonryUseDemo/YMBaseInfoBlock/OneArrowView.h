//
//  OneArrowView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/6/4.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "YMBaseInfoView.h"

@interface OneArrowView : YMBaseInfoView

@property (nonatomic, strong)UIImageView *arrowImageView;
//@property (nonatomic, strong) UIImageView* arrowImageView;
//- (void)setTip:(NSString*)tip;
- (void)setArrowHide:(BOOL)hide;

@end
