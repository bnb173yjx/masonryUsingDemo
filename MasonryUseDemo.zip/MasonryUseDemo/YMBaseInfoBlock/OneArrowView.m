//
//  OneArrowView.m
//  YanmianTest
//
//  Created by 叶杨 on 16/6/4.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "OneArrowView.h"

@implementation OneArrowView
- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self setupView];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupView];
    }
    return self;
}

- (void)setupView {
    [self addSubview:self.arrowImageView];
    [self addMasonryToview];
}
- (void)addMasonryToview {
    WS(weakSelf)
    [self.arrowImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(weakSelf.mas_right).with.offset(-8);
        make.centerY.mas_equalTo(weakSelf.mas_centerY);
    }];
}

- (void)setArrowHide:(BOOL)hide {
    self.arrowImageView.hidden = hide;
}

- (UIImageView*)arrowImageView {
    if (_arrowImageView == nil) {
        _arrowImageView = [[UIImageView alloc] init];
        _arrowImageView.image = [UIImage imageNamed:@"arrow_right"];
    }
    return _arrowImageView;
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    if (![self.superview.superview isKindOfClass:[UITableViewCell class]]) {
        [self setBackgroundColor:NormalBgColor];
    }
    
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesEnded:touches withEvent:event];
    if (![self.superview.superview isKindOfClass:[UITableViewCell class]]) {
        [self setBackgroundColor:[UIColor whiteColor]];
    }
}

- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesCancelled:touches withEvent:event];
    if (![self.superview.superview isKindOfClass:[UITableViewCell class]]) {
        [self setBackgroundColor:[UIColor whiteColor]];
    }
}



/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
