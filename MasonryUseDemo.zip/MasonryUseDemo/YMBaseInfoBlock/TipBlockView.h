//
//  YMBaseInfoView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "YMBaseInfoView.h"


//仅有一个label
@interface TipBlockView : YMBaseInfoView
@property (nonatomic, strong) UILabel* tipLab;
- (void)setTipLabText:(NSString *)text;
@end
