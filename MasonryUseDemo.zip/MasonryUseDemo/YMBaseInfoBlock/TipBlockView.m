//
//  YMBaseInfoView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//


#import "TipBlockView.h"

@interface TipBlockView()

@end

@implementation TipBlockView


- (instancetype)init {
    if (self = [super init]) {
        [self setupTipBlockView];
    }
    return self;
}

- (void)setupTipBlockView {
    self.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.tipLab];
    [self addTipBlockViewMasonry];
}

- (void)addTipBlockViewMasonry {
    WS(weakSelf)
    [self.tipLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.mas_left).with.offset(16);
//        make.width.mas_equalTo(120);
        make.centerY.mas_equalTo(weakSelf.mas_centerY);
    }];
    
    [self.tipLab sizeToFit];
    

}

- (UILabel *)tipLab {
    if (_tipLab == nil) {
        _tipLab = [[UILabel alloc] init];
        [_tipLab setFont:CreateFont(14)];
    }
    return _tipLab;

}

- (void)setTipLabText:(NSString *)text {
    self.tipLab.text = text;
}

@end
