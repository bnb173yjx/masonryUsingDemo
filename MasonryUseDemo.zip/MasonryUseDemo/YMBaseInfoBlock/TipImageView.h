//
//  TipImageView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/6/3.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "TipBlockView.h"

/*
 左边一个label右边一个头像
 高度一定要大于等于80;
 */
@interface TipImageView : TipBlockView

@property (nonatomic, strong)UIImageView *imageView;


@end
