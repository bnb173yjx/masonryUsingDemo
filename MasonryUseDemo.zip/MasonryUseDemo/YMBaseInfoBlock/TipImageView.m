//
//  TipImageView.m
//  YanmianTest
//
//  Created by 叶杨 on 16/6/3.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "TipImageView.h"

@implementation TipImageView

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        [self setupTipImageView];
    }
    return self;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self setupTipImageView];
    }
    return self;
}



- (void)setupTipImageView {
 
    self.imageView = [[UIImageView alloc]init];
    [self addSubview:self.imageView];
    [self addMasonryToTipImageView];
    
    
}

- (void)addMasonryToTipImageView {
    WS(weakSelf)
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(weakSelf.mas_right).with.offset(-15);
        make.centerY.equalTo(weakSelf);
        make.width.and.height.mas_equalTo(80);
    }];
    self.imageView.backgroundColor = [UIColor blackColor];
    self.imageView.layer.cornerRadius = 40;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
