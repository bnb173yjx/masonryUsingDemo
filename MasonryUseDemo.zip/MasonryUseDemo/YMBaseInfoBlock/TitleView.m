//
//  YMBaseInfoView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "TitleView.h"

@interface TitleView()

@end

@implementation TitleView

- (instancetype)init {
    if (self = [super init]) {
        [self setupTitleView];
    }
    return self;
}

- (void)setupTitleView {
    self.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.titleTextField];
    [self addTitleViewMasonry];
}

- (void)addTitleViewMasonry {
    WS(weakSelf)
    [self.titleTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(weakSelf.mas_left).with.offset(16);
        make.right.equalTo(weakSelf.mas_right).with.offset(-16);
        make.centerY.mas_equalTo(weakSelf.mas_centerY);
    }];
}

- (UITextField*)titleTextField {
    if (_titleTextField == nil) {
        _titleTextField = [[UITextField alloc] init];
        _titleTextField.textColor = HEXRGB(0x333333);
        _titleTextField.font = CreateFont(14);
        _titleTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"输入标题(可选填)" attributes:@{NSForegroundColorAttributeName: HEXRGB(0x999999)}];
        [_titleTextField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _titleTextField;
}

- (void)setPlaceholderStr:(NSString*)str {
    self.titleTextField.attributedPlaceholder = [[NSAttributedString alloc] initWithString:str attributes:@{NSForegroundColorAttributeName: HEXRGB(0x999999)}];
}

- (void)clearButtonMode:(UITextFieldViewMode)viewMode {
    self.titleTextField.clearButtonMode = viewMode;
}

- (void)textFieldDidChange:(UITextField *)textField {
    if (self.titleTextField != textField) {
        return;
    }
    
    if (self.limitLength <= 0) {
        return;
    }
    
    NSString *toBeString = textField.text;
    
    //获取高亮部分
    UITextRange *selectedRange = [textField markedTextRange];
    UITextPosition *position = [textField positionFromPosition:selectedRange.start offset:0];
    
    // 没有高亮选择的字，则对已输入的文字进行字数统计和限制
    if (!position)
    {
        if (toBeString.length > self.limitLength)
        {
            NSRange rangeIndex = [toBeString rangeOfComposedCharacterSequenceAtIndex:self.limitLength];
            if (rangeIndex.length == 1)
            {
                textField.text = [toBeString substringToIndex:self.limitLength];
            }
            else
            {
                NSRange rangeRange = [toBeString rangeOfComposedCharacterSequencesForRange:NSMakeRange(0, self.limitLength)];
                textField.text = [toBeString substringWithRange:rangeRange];
            }
        }
    }
}



- (NSString*)titleStr {
    return self.titleTextField.text;
}


@end

