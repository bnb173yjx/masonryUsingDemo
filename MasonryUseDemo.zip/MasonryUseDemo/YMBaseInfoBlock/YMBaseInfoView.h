//
//  YMBaseInfoView.h
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import <UIKit/UIKit.h>
//这是个线的类型typeEnum默认是Default
typedef NS_ENUM(NSInteger, YmViewLineStyle) {
    YmViewLineStyleNone,
    YmViewLineStyleDefault,
    YmViewLineStyleFill,
};
//这是一个基类用来画上下线
@interface YMBaseInfoView : UIView


@property (nonatomic, assign) CGFloat leftSeparatorSpace;
@property (nonatomic, assign) CGFloat rightSeparatorSpace;
@property (nonatomic, assign) YmViewLineStyle topLineStyle;
@property (nonatomic, assign) YmViewLineStyle bottomLineStyle;
@property (nonatomic, strong) UIColor* lineColor;
/*
 不能直接赋值，得通过addGreyAction方法来操作
 */
@property (nonatomic, copy)ActionBlock actionBlock;
//添加点击时视图背景颜色变灰
- (void)addGreyAction:(ActionBlock)block;
@end
