//
//  YMBaseInfoView.m
//  YanmianTest
//
//  Created by 叶杨 on 16/5/14.
//  Copyright © 2016年 叶杨. All rights reserved.
//

#import "YMBaseInfoView.h"
@interface YMBaseInfoView ()
@property (nonatomic, strong) UIView* topLine;
@property (nonatomic, strong) UIView* bottomLine;
@property (nonatomic, strong) UIButton *grayButton;

@end
@implementation YMBaseInfoView

- (instancetype)init{
    if (self = [super init]) {
        self.rightSeparatorSpace = 0.0f;
        self.leftSeparatorSpace = 0.f;
        self.lineColor = HEXRGB(0xdbdbdb);
        self.topLineStyle = YmViewLineStyleNone;
        self.bottomLineStyle = YmViewLineStyleNone;
        self.backgroundColor = [UIColor whiteColor];
        self.topLine = [[UIView alloc] init];
        self.bottomLine = [[UIView alloc] init];
        [self addSubview:self.topLine];
        [self addSubview:self.bottomLine];
        self.topLine.backgroundColor = self.lineColor;
        self.bottomLine.backgroundColor = self.lineColor;
    }
    return self;
}

- (void)setTopLineStyle:(YmViewLineStyle)topLineStyle
{
    _topLineStyle = topLineStyle;
    //    [self setNeedsDisplay];
}

- (void)setBottomLineStyle:(YmViewLineStyle)bottomLineStyle
{
    _bottomLineStyle = bottomLineStyle;
    //    [self setNeedsDisplay];
}

- (void)setLeftSeparatorSpace:(CGFloat)leftSeparatorSpace
{
    _leftSeparatorSpace = leftSeparatorSpace;
    //    [self setNeedsDisplay];
}

- (void)setRightSeparatorSpace:(CGFloat)rightSeparatorSpace
{
    _rightSeparatorSpace = rightSeparatorSpace;
    //    [self setNeedsDisplay];
}

- (void)setLineColor:(UIColor *)lineColor {
    _lineColor = lineColor;
    self.topLine.backgroundColor = lineColor;
    self.bottomLine.backgroundColor = lineColor;
}

- (void)layoutSubviews {
    [self bringSubviewToFront:self.topLine];
    [self bringSubviewToFront:self.bottomLine];
    if (self.topLineStyle != YmViewLineStyleNone) {
        CGFloat startX = (self.topLineStyle == YmViewLineStyleFill ? 0 : _leftSeparatorSpace);
        self.topLine.frame = CGRectMake(startX, 0, self.frame.size.width - self.rightSeparatorSpace, ONELINE_WIDTH);
        self.topLine.hidden = NO;
    } else {
        self.topLine.hidden = YES;
    }
    if (self.bottomLineStyle != YmViewLineStyleNone) {
        CGFloat startX = (self.bottomLineStyle == YmViewLineStyleNone ? 0 : _leftSeparatorSpace);
        self.bottomLine.frame = CGRectMake(startX, self.frame.size.height - ONELINE_WIDTH, self.frame.size.width - self.rightSeparatorSpace, ONELINE_WIDTH);
        self.bottomLine.hidden = NO;
    } else {
        self.bottomLine.hidden = YES;
    }
    
    //layoutSubviews 放最后面解决iOS7crash的bug
    [super layoutSubviews];
}
//- (instancetype)init
//{
//    if (self = [super init]) {
//        
//        _trightSeparatorSpace = 0.0f;
//        _tleftSeparatorSpace = 0.0f;
//        
//        _brightSeparatorStyle = 0.0f;
//        _bleftSeperatorSpace = 0.0f;
//        
//        _lineColor = LineColor;
//        
//        _topLineStyle = YmViewLineStyleNone;
//        _bottomLineStyle = YmViewLineStyleNone;
//        
//    }
//    return self;
//}
//
//- (void)setTopLineStyle:(YmViewLineStyle)topLineStyle
//{
//    _topLineStyle = topLineStyle;
//    [self setNeedsDisplay];
//}
//
//- (void)setBottomLineStyle:(YmViewLineStyle)bottomLineStyle
//{
//    _bottomLineStyle = bottomLineStyle;
//    [self setNeedsDisplay];
//}
//
//- (void)setTrightSeparatorSpace:(CGFloat)trightSeparatorSpace
//{
//    _trightSeparatorSpace = trightSeparatorSpace;
//    [self setNeedsDisplay];
//}
//
//- (void)setTleftSeparatorSpace:(CGFloat)tleftSeparatorSpace
//{
//    _tleftSeparatorSpace = tleftSeparatorSpace;
//    [self setNeedsDisplay];
//}
//
//- (void)setBleftSeperatorSpace:(CGFloat)bleftSeperatorSpace
//{
//    _bleftSeperatorSpace = bleftSeperatorSpace;
//    [self setNeedsDisplay];
//}
//
//- (void)setBrightSeparatorStyle:(CGFloat)brightSeparatorStyle
//{
//    _brightSeparatorStyle = brightSeparatorStyle;
//    [self setNeedsDisplay];
//}
//


//无法适配ios7.0失真明显,fuck myself
////每当一些属性设置的时候重复画线
//- (void)drawRect:(CGRect)rect
//{
//    [super drawRect:rect];
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    CGContextSetLineWidth(context, ONELINE_WIDTH);
//    [self.lineColor set];
//    if (self.topLineStyle != YmViewLineStyleNone) {
//        CGContextBeginPath(context);
//        CGFloat startX = (self.topLineStyle == YmViewLineStyleFill ? 0 : _tleftSeparatorSpace);
//        CGFloat endX = self.frame.size.width - self.trightSeparatorSpace;
//        CGFloat y = 0;
//        CGContextMoveToPoint(context, startX, y);
//        CGContextAddLineToPoint(context, endX, y);
//        CGContextStrokePath(context);
//    }
//    if (self.bottomLineStyle != YmViewLineStyleNone) {
//        CGContextBeginPath(context);
//        CGFloat startX = (self.topLineStyle == YmViewLineStyleFill ? 0 : _bleftSeperatorSpace);
//        CGFloat endX = self.frame.size.width - self.brightSeparatorStyle;
//        CGFloat y = self.frame.size.height;
//        CGContextMoveToPoint(context, startX, y);
//        CGContextAddLineToPoint(context, endX, y);
//        CGContextStrokePath(context);
//    }
//
//}
//添加视图背景颜色变灰的颜色
- (void)addGreyAction:(ActionBlock)block
{
    self.actionBlock = block;
    UITapGestureRecognizer *lPg = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapPressAction:)];
//    lPg.minimumPressDuration = 0.000001f;
    
    [self addGestureRecognizer:lPg];
    
}
- (void)tapPressAction:(UITapGestureRecognizer *)lPg
{
    if (self.actionBlock) {
        self.actionBlock();
    }
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
